# GitHub classic themes

The classic `GitHub Light` and `GitHub Dark` themes were built before github.com added themes. They are still available but use a different color system and are not compatible with the rest of the themes.